/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CSTCopyright.IDCS.model;

/**
 *
 * @author macbook
 */
public class Constant {
    
    public static final String registSuccess = "Regist Success!";
    public static final String registFail_ExitsAccount = "The IDCS Account was exist. Please try another name";
    public static final String registFail_DifferentPaswd = "";
    
    //login notif
    public static final String errorlogin1= "User Name or password invalid";
    public static final String errorlogin2= "Required username and password!";
    
    //User Type
    public static final int Admin = 1;
    public static final int User = 0;
   
}
