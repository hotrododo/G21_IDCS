/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function frmValidate() {
    var val = document.frmDomain.name.value;
    if (/^([a-z0-9]([-a-z0-9]*[a-z0-9])?\\.)+((a[cdefgilmnoqrstuwxz]|aero|arpa)|(b[abdefghijmnorstvwyz]|biz)|(c[acdfghiklmnorsuvxyz]|cat|com|coop)|d[ejkmoz]|(e[ceghrstu]|edu)|f[ijkmor]|(g[abdefghilmnpqrstuwy]|gov)|h[kmnrtu]|(i[delmnoqrst]|info|int)|(j[emop]|jobs)|k[eghimnprwyz]|l[abcikrstuvy]|(m[acdghklmnopqrstuvwxyz]|mil|mobi|museum)|(n[acefgilopruz]|name|net)|(om|org)|(p[aefghklmnrstwy]|pro)|qa|r[eouw]|s[abcdeghijklmnortvyz]|(t[cdfghjklmnoprtvwz]|travel)|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw])$/i.test(val)) {
        alert("Valid Domain Name");
        return true;
    } else {
        alert("Enter Valid Domain Name");
        val.name.focus();
        return false;
    }
}
function showDialog() {
    $(document).ready(function () {
        $("#myPopup").fadeIn("slow");
        $("#userList").fadeOut();
    });

}
function hideDialog() {
    $(document).ready(function () {
        $("#myPopup").fadeOut();
        $("#userList").fadeIn();
    });
}

